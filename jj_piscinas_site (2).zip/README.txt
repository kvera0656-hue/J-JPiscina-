J&J Construcciones - Sitio web listo para usar
---------------------------------------------
Archivos incluidos:
- index.html        -> Página principal (usa imágenes desde Unsplash)
- README.txt        -> Este archivo
Cómo usar:
1) Descomprimí el ZIP.
2) Subí la carpeta a cualquier hosting estático (Netlify, Vercel, GitHub Pages, o tu hosting).
3) Opcional: reemplazá las URL de imágenes por tus fotos locales (colocar en /assets y actualizar rutas).
4) Para recibir formularios por email de forma profesional, integrá un servicio (Formspree, Google Forms o backend propio).
Contacto del creador: J (cliente)
